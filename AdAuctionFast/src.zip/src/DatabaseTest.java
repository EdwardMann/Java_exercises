import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

public class DatabaseTest extends TestCase {
//     private String clickpath = "../Testing/2_week_campaign_2_short/click_log.csv";
//     private String impressionpath = "../Testing/2_week_campaign_2_short/impression_log.csv";
//     private String serverpath = "../Testing/2_week_campaign_2_short/server_log.csv";

    private String clickpath = "D:/Documents/Programming/Java/Workspace/adauction24/Testing/2_week_campaign_2_short/click_log.csv";
    private String impressionpath = "D:/Documents/Programming/Java/Workspace/adauction24/Testing/2_week_campaign_2_short/impression_log.csv";
    private String serverpath = "D:/Documents/Programming/Java/Workspace/adauction24/Testing/2_week_campaign_2_short/server_log.csv";

    private File clickfile = new File(clickpath);
    private File impressionfile = new File(impressionpath);
    private File serverfile = new File(serverpath);

    /**
     * Tests if OpenCSV and DataInterface work with correct inputs (for short campaign)
     *
     * @throws IOException
     * @throws SQLException 
     * @throws ParseException 
     */
    public void testWorks() throws IOException, SQLException, ParseException {
        new OpenCSV(clickfile, impressionfile, serverfile);

        Map<Metric, Double> results = DataInterface.getAllMetrics();

        Map<Metric, Double> answers = new HashMap<>();
        answers.put(Metric.NumberOfImpressions,         16.0);
        answers.put(Metric.NumberOfClicks,              13.0);
        answers.put(Metric.NumberOfUniques,             13.0);
        answers.put(Metric.NumberOfBouncesPagesViewed,  5.0);
        answers.put(Metric.NumberOfBouncesTime,         1.0);
        answers.put(Metric.NumberOfConversions,         5.0);
        answers.put(Metric.TotalCost,                   0.028365000000000005);
        answers.put(Metric.CTR,                         5.3076923076923075);
        answers.put(Metric.CPA,                         0.005673000000000001);
        answers.put(Metric.CPC,                         0.0021819230769230774);
        answers.put(Metric.CPM,                         0.0017728125000000003);
        answers.put(Metric.BounceRateTime,              0.07692307692307693);
        answers.put(Metric.BounceRatePagesViewed,       0.38461538461538464);

        for (Metric m : Metric.values()) {
            assertEquals(answers.get(m), results.get(m));
        }
    }
    
    public void testAgeFilter() throws IOException, SQLException, ParseException {
        new OpenCSV(clickfile, impressionfile, serverfile);

        ArrayList<String> age = new ArrayList<>(Arrays.asList("<25", ">54"));
        Filter filter = new Filter(null, null, age, null, null, null);
        
        DataInterface.filterLogs(filter);

        Map<Metric, Double> results = DataInterface.getAllMetrics();

        Map<Metric, Double> answers = new HashMap<>();
        answers.put(Metric.NumberOfImpressions,         6.0);
        answers.put(Metric.NumberOfClicks,              2.0);
        answers.put(Metric.NumberOfUniques,             2.0);
        answers.put(Metric.NumberOfBouncesPagesViewed,  5.0);
        answers.put(Metric.NumberOfBouncesTime,         1.0);
        answers.put(Metric.NumberOfConversions,         1.0);
        answers.put(Metric.TotalCost,                   0.006907);
        answers.put(Metric.CTR,                         6.5);
        answers.put(Metric.CPA,                         0.006907);
        answers.put(Metric.CPC,                         0.0034535);
        answers.put(Metric.CPM,                         0.00172675);
        answers.put(Metric.BounceRateTime,              0.5);
        answers.put(Metric.BounceRatePagesViewed,       2.5);

        for (Metric m : Metric.values()) {
            assertEquals(answers.get(m), results.get(m));
        }
    }
    
    public void testGenderFilter() throws IOException, SQLException, ParseException {
        new OpenCSV(clickfile, impressionfile, serverfile);

        ArrayList<String> gender = new ArrayList<>(Arrays.asList("Female"));

        Map<Metric, Double> results = DataInterface.getAllMetrics();

        Map<Metric, Double> answers = new HashMap<>();
        answers.put(Metric.NumberOfImpressions,         12.0);
        answers.put(Metric.NumberOfClicks,              10.0);
        answers.put(Metric.NumberOfUniques,             10.0);
        answers.put(Metric.NumberOfBouncesPagesViewed,  5.0);
        answers.put(Metric.NumberOfBouncesTime,         1.0);
        answers.put(Metric.NumberOfConversions,         5.0);
        answers.put(Metric.TotalCost,                   0.024108000000000004);
        answers.put(Metric.CTR,                         5.5);
        answers.put(Metric.CPA,                         0.0048216000000000005);
        answers.put(Metric.CPC,                         0.0024108000000000003);
        answers.put(Metric.CPM,                         0.0020090000000000004);
        answers.put(Metric.BounceRateTime,              0.1);
        answers.put(Metric.BounceRatePagesViewed,       0.5);

        for (Metric m : Metric.values()) {
            assertEquals(answers.get(m), results.get(m));
        }
    }
    
    
    public void testIncomeFilter() throws IOException, SQLException, ParseException {
        new OpenCSV(clickfile, impressionfile, serverfile);

        ArrayList<String> income = new ArrayList<>(Arrays.asList("Low"));

        Map<Metric, Double> results = DataInterface.getAllMetrics();

        Map<Metric, Double> answers = new HashMap<>();
        answers.put(Metric.NumberOfImpressions,         4.0);
        answers.put(Metric.NumberOfClicks,              4.0);
        answers.put(Metric.NumberOfUniques,             4.0);
        answers.put(Metric.NumberOfBouncesPagesViewed,  5.0);
        answers.put(Metric.NumberOfBouncesTime,         1.0);
        answers.put(Metric.NumberOfConversions,         1.0);
        answers.put(Metric.TotalCost,                   0.011040000000000001);
        answers.put(Metric.CTR,                         5.5);
        answers.put(Metric.CPA,                         0.011040000000000001);
        answers.put(Metric.CPC,                         0.0027600000000000003);
        answers.put(Metric.CPM,                         0.0027600000000000003);
        answers.put(Metric.BounceRateTime,              0.25);
        answers.put(Metric.BounceRatePagesViewed,       1.25);

        for (Metric m : Metric.values()) {
            assertEquals(answers.get(m), results.get(m));
        }
    }
    
    public void testContextFilter() throws IOException, SQLException, ParseException {
        new OpenCSV(clickfile, impressionfile, serverfile);
        
        ArrayList<String> context = new ArrayList<>(Arrays.asList("Shopping", "Social"));
        
        Map<Metric, Double> results = DataInterface.getAllMetrics();
        
        Map<Metric, Double> answers = new HashMap<>();
        answers.put(Metric.NumberOfImpressions,         3.0);
        answers.put(Metric.NumberOfClicks,              3.0);
        answers.put(Metric.NumberOfUniques,             3.0);
        answers.put(Metric.NumberOfBouncesPagesViewed,  5.0);
        answers.put(Metric.NumberOfBouncesTime,         1.0);
        answers.put(Metric.NumberOfConversions,         2.0);
        answers.put(Metric.TotalCost,                   0.003001);
        answers.put(Metric.CTR,                         4.0);
        answers.put(Metric.CPA,                         0.0015005);
        answers.put(Metric.CPC,                         0.0010003333333333333);
        answers.put(Metric.CPM,                         0.0010003333333333333);
        answers.put(Metric.BounceRateTime,              0.3333333333333333);
        answers.put(Metric.BounceRatePagesViewed,       1.6666666666666667);
        
        for (Metric m : Metric.values()) {
            assertEquals(answers.get(m), results.get(m));
        }
    }

    public void testMultipleFilters() throws IOException, SQLException, ParseException {
        new OpenCSV(clickfile, impressionfile, serverfile);

        ArrayList<String> age = new ArrayList<>(Arrays.asList("25-34", "35-44", "45-54"));
        ArrayList<String> gender = new ArrayList<>(Arrays.asList("Female"));
        ArrayList<String> income = new ArrayList<>(Arrays.asList("Medium", "High"));
        ArrayList<String> context = new ArrayList<>(Arrays.asList("Blog", "News"));

        Map<Metric, Double> results = DataInterface.getAllMetrics();

        Map<Metric, Double> answers = new HashMap<>();
        answers.put(Metric.NumberOfImpressions,         3.0);
        answers.put(Metric.NumberOfClicks,              3.0);
        answers.put(Metric.NumberOfUniques,             3.0);
        answers.put(Metric.NumberOfBouncesPagesViewed,  5.0);
        answers.put(Metric.NumberOfBouncesTime,         1.0);
        answers.put(Metric.NumberOfConversions,         1.0);
        answers.put(Metric.TotalCost,                   0.003775);
        answers.put(Metric.CTR,                         5.666666666666667);
        answers.put(Metric.CPA,                         0.003775);
        answers.put(Metric.CPC,                         0.0012583333333333333);
        answers.put(Metric.CPM,                         0.0012583333333333333);
        answers.put(Metric.BounceRateTime,              0.3333333333333333);
        answers.put(Metric.BounceRatePagesViewed,       1.6666666666666667);

        for (Metric m : Metric.values()) {
            assertEquals(answers.get(m), results.get(m));
        }
    }
    
    /**
     * Tests data for graph. Only uses one metric for the sake of developer time
     * 
     * @throws IOException
     * @throws SQLException
     * @throws ParseException 
     */
    public void testGraph() throws IOException, SQLException, ParseException {
        new OpenCSV(clickfile, impressionfile, serverfile);
        
        Map<String, Double> results = DataInterface.getGraphData(Metric.NumberOfClicks);
        
        Map<Date, Double> answers = new HashMap<Date, Double>();
        answers.put(new Date(1420113602000L), 4.0);
        answers.put(new Date(1420200002000L), 4.0);
        answers.put(new Date(1420286402000L), 4.0);
        answers.put(new Date(1420372802000L), 1.0);
        
        assertTrue(answers.equals(results));
        
    }

    /**
     * Test result of if user chooses the files in the wrong order
     * 
     * @throws IOException
     * @throws ParseException 
     */
    public void testWrongOrderFiles() throws IOException, ParseException {
        try {
            new OpenCSV(serverfile, clickfile, impressionfile);
        } catch (IOException e) {
            fail("Failed to handle wrong order");
        }
    }

}
