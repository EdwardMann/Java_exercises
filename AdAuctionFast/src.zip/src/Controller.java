import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Map;
import java.util.TreeMap;

public class Controller {
    EvaluationTool gui;

    /**
     * Fetches the map containing the mapping of key metrics to their corresponding values
     *
     * @return
     */
    public Map<Metric, Double> getKeyMetrics() {
        return DataInterface.getAllMetrics();
    }

    /**
     * Tells OpenCSV to load the three selected csv files into the database
     *
     * @param clickLog
     *            A path to the location of the click log
     * @param impressionLog
     *            A path to the location of the impression log
     * @param serverLog
     *            A path to the location of the server log
     * @throws IOException
     * @throws ParseException
     */
    public void openCSV(File clickLog, File impressionLog, File serverLog) throws IOException, ParseException {
        new OpenCSV(clickLog, impressionLog, serverLog);
    }

    public Map<String, Double> getGraphData(Metric metric) throws ParseException {
        return DataInterface.getGraphData(metric);
    }
    
    public void resetLogs(){
        DataInterface.resetLogs();
    }
    
    public TreeMap<String, Double> getHistogramPairs(){
        return DataInterface.getHistogramPairs();
    }
}
