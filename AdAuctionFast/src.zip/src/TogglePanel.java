import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;

public class TogglePanel extends JPanel{
	private EvaluationTool gui;
	private JRadioButton bounceTime;
	private JRadioButton bouncePage;
	static JButton apply;
	private SpinnerModel pagesViewedModel;
	private SpinnerModel timeSpentModel;
	private final int maximumTimeBounce = 120; //maximum amount of seconds a bounce can be registered as
	private final int maximumPagesBounce = 10; //maximum amount of pages a bounce can be registered as
	private int defaultTime;
	private int defaultPage;
	
	public TogglePanel(EvaluationTool gui){
		this.gui = gui;
		defaultTime = DataInterface.getMinSeconds();
		defaultPage = DataInterface.getMinPages();
		initPanel();
	}

	void initPanel(){
		GridBagLayout layout = new GridBagLayout();
		setLayout(layout);
		
		setBorder(BorderFactory.createTitledBorder(null, "Bounce Rate", TitledBorder.CENTER,
				TitledBorder.TOP, new Font("times new roman",Font.ITALIC,16),new Color(153, 0, 0)));
//		setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Bounce Rate",
//			TitledBorder.CENTER, TitledBorder.TOP, null, new Color(153, 0, 0)));
		
		//JComboBox
		String[] bounceRates = new String[]{"Seconds Spent", "Pages Viewed"};
		JComboBox<String> jcb = new JComboBox<String>(bounceRates);
		add(jcb,new GBC(0, 0).setFill(GBC.LINE_START).setWeight(0, 0).setInsets(0, 0, 0, 0));
//		add(jcb);
		
		//JSpinner
		timeSpentModel = new SpinnerNumberModel(defaultTime, 1, maximumTimeBounce, 1);
		pagesViewedModel = new SpinnerNumberModel(defaultPage, 1, maximumPagesBounce, 1);
		JSpinner spinner = new JSpinner(timeSpentModel);
		centerSpinner(spinner);
		add(spinner,new GBC(1, 0).setFill(GBC.EAST).setWeight(0, 0).setInsets(0, 0, 0, 0));
//		add(spinner);

		//JButton
		.button {
		    -fx-text-fill: white;
		    -fx-font-family: "Arial Narrow";
		    -fx-font-weight: bold;
		    -fx-background-color: linear-gradient(#61a2b1, #2A5058);
		    -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );
		}
		apply = new JButton("Apply");
		apply.setEnabled(false);
		add(apply,new GBC(0, 1).setFill(GBC.BOTH).setWeight(1.0, 0).setInsets(0, 70, 0, 0));
//		add(apply);
		
		//Changes the SQL filter queries to match the bounce rate specified 
		apply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				apply.setBackground(Color.RED);
				if(jcb.getSelectedItem().equals(bounceRates[0])){ //time spent
					defaultPage = (Integer) spinner.getValue();
					DataInterface.setMinPages(defaultPage);
				}else if(jcb.getSelectedItem().equals(bounceRates[1])){ //pages viewed
					defaultTime = (Integer) spinner.getValue();
					DataInterface.setMinSeconds(defaultTime);
				}
				gui.updateKeyMetrics();
			}
		});
		
		
		//ActionListener for JComboBox
		jcb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(jcb.getSelectedItem().equals(bounceRates[0])){ //time spent
					defaultTime = (Integer) spinner.getValue();
					spinner.setModel(pagesViewedModel);
				}else if(jcb.getSelectedItem().equals(bounceRates[1])){ //pages viewed
					defaultPage = (Integer) spinner.getValue();
					spinner.setModel(timeSpentModel);
				}
				centerSpinner(spinner);
			}
		});
		
	}
	
	void centerSpinner(JSpinner spinner){
		JFormattedTextField txt = ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField();
		txt.setColumns(4);
		txt.setHorizontalAlignment(JTextField.CENTER);
	}
}
