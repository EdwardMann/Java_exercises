/**
 * Created by Douglas on 22/02/17.
 */
public enum TableName
{
    ImpressionPeople, ImpressionInstance, Click, Server
}
