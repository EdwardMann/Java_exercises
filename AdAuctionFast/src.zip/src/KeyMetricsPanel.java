import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class KeyMetricsPanel extends JPanel {

	JPanel metrics;

	JLabel impressionsval;
	JLabel clicksval;
	JLabel uniquesval;
	JLabel bouncesTimeval;
	JLabel bouncesval;
	JLabel conversionsval;
	JLabel costval;
	JLabel ctrval;
	JLabel cpaval;
	JLabel cpcval;
	JLabel cpmval;
	JLabel bounceTimeRateval;
	JLabel bounceRateval;

	KeyMetricsPanel() {
		init();
		initMetrics();

	}

	void init() {
		new JPanel();
//		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

	}

	void initMetrics() {
		GridBagLayout layout = new GridBagLayout();
		setLayout(layout);
		metrics = new JPanel(layout);
		JPanel emptyPanel = new JPanel(layout);
	
		this.setPreferredSize(new Dimension(250, 820));
		metrics.setBorder(BorderFactory.createTitledBorder(null, "Metrics", TitledBorder.CENTER,
				TitledBorder.TOP, new Font("times new roman",Font.ITALIC,16),new Color(153, 0, 0)));
//		metrics.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Metrics", TitledBorder.CENTER,
//				TitledBorder.TOP, null, new Color(153, 0, 0)));
//		metrics.BorderFactory.createLineBorder(color, thickness)
//		metrics.setSize(new Dimension(150, 600));
		add(metrics,new GBC(0, 0,1,1).setFill(GBC.BOTH).setWeight(1.0, 0.40).setInsets(0, 0, 0, 0));
		add(emptyPanel,new GBC(0, 4,1,1).setFill(GBC.BOTH).setWeight(1.0, 0.30).setInsets(0, 0, 0, 0));
//		add(metrics);
		
		
		
		/* Insert all the current key metrics */
		JLabel impressions = new JLabel("Impressions:");
		JLabel clicks = new JLabel("Clicks:");
		JLabel uniques = new JLabel("Uniques:");
		JLabel bouncesTime = new JLabel("Bounces (Time):");
		JLabel bounces = new JLabel("Bounces (Pages):");
		JLabel conversions = new JLabel("Conversions:");
		JLabel cost = new JLabel("Total Cost:");
		
		JLabel ctr = new JLabel("CTR:");
		ctr.setToolTipText("Click-through-rate - The average number of clicks per impression.");
		
		JLabel cpa = new JLabel("CPA:");
		cpa.setToolTipText("Cost-per-acquisition - The average amount of money spent on an "
				+ "advertising campaign for each conversion.");
		
		JLabel cpc = new JLabel("CPC:");
		cpc.setToolTipText(
				"Cost-per-click - The average amount of money spent on an " + "advertising campaign for each click.");
		
		JLabel cpm = new JLabel("CPM:");
		cpm.setToolTipText("Cost-per-thousand impressions - The average amount of money spent "
				+ "on an advertising campaign for every one thousand impressions.");
		
		JLabel bounceTimeRate = new JLabel("Bounce Rate By Time:");
		JLabel bounceRate = new JLabel("Bounce Rate By Pages:");

		impressionsval = new JLabel("", JLabel.HORIZONTAL);
		clicksval = new JLabel("", JLabel.HORIZONTAL);
		uniquesval = new JLabel("", JLabel.HORIZONTAL);
		bouncesTimeval = new JLabel("", JLabel.HORIZONTAL);
		bouncesval = new JLabel("", JLabel.HORIZONTAL);
		conversionsval = new JLabel("", JLabel.HORIZONTAL);
		costval = new JLabel("", JLabel.HORIZONTAL);
		ctrval = new JLabel("", JLabel.HORIZONTAL);
		cpaval = new JLabel("", JLabel.HORIZONTAL);
		cpcval = new JLabel("", JLabel.HORIZONTAL);
		cpmval = new JLabel("", JLabel.HORIZONTAL);
		bounceTimeRateval = new JLabel("", JLabel.HORIZONTAL);
		bounceRateval = new JLabel("", JLabel.HORIZONTAL);

//		metrics.add(impressions);		metrics.add(impressionsval);
//		metrics.add(clicks);			metrics.add(clicksval);
//		metrics.add(uniques);			metrics.add(uniquesval);
//		metrics.add(bouncesTime);		metrics.add(bouncesTimeval);
//		metrics.add(bounces);			metrics.add(bouncesval);
//		metrics.add(conversions);		metrics.add(conversionsval);
//		metrics.add(cost);				metrics.add(costval);
//		metrics.add(cpc);				metrics.add(cpcval);
//		metrics.add(ctr);				metrics.add(ctrval);
//		metrics.add(cpa);				metrics.add(cpaval);
//		metrics.add(cpm);				metrics.add(cpmval);
//		metrics.add(bounceTimeRate);	metrics.add(bounceTimeRateval);
//		metrics.add(bounceRate);		metrics.add(bounceRateval);
		metrics.add(impressions,new GBC(0, 0).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(conversions,new GBC(0, 1).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(bouncesTime,new GBC(0, 2).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(bounceTimeRate,new GBC(0, 3).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(bounceRate,new GBC(0, 4).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(bounces,new GBC(0, 5).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(clicks,new GBC(0, 6).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(cost,new GBC(0, 7).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(uniques,new GBC(0, 8).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(cpc,new GBC(0, 9).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(ctr,new GBC(0, 10).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(cpa,new GBC(0, 11).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(cpm,new GBC(0, 12).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		
		
		
		metrics.add(impressionsval,new GBC(1, 0).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(conversionsval,new GBC(1, 1).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(bouncesTimeval,new GBC(1, 2).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(bounceTimeRateval,new GBC(1, 3).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(bounceRateval,new GBC(1, 4).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(bouncesval,new GBC(1, 5).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(clicksval,new GBC(1, 6).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(costval,new GBC(1, 7).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(uniquesval,new GBC(1, 8).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(cpcval,new GBC(1, 9).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(ctrval,new GBC(1, 10).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(cpaval,new GBC(1, 11).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));
		metrics.add(cpmval,new GBC(1, 12).setFill(GBC.HORIZONTAL).setWeight(0.01, 0.25).setInsets(0, 0, 10, 0));

	}

	JLabel getImpressions() {
		return impressionsval;
	}

	JLabel getClicks() {
		return clicksval;
	}

	JLabel getUniques() {
		return uniquesval;
	}

	JLabel getBounces() {
		return bouncesval;
	}

	JLabel getBouncesTime() {
		return bouncesTimeval;
	}

	JLabel getConversions() {
		return conversionsval;
	}

	JLabel getCosts() {
		return costval;
	}

	JLabel getCTR() {
		return ctrval;
	}

	JLabel getCPA() {
		return cpaval;
	}

	JLabel getCPC() {
		return cpcval;
	}

	JLabel getCPM() {
		return cpmval;
	}

	JLabel getBounceRateTime() {
		return bounceTimeRateval;
	}
	
	JLabel getBounceRate() {
		return bounceRateval;
	}
}
