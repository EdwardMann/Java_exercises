/**
 * Created by Douglas on 22/02/17.
 */
public enum ColumnName
{
    ClickDate, ID, Gender, Age, Income, Context, ImpressionCost, EntryDate, ExitDate, PagesViewed, Conversion, ClickCost, ImpDate
}
