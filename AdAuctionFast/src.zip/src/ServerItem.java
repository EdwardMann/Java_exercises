import java.util.Date;

public class ServerItem extends Item{

	Date exitDate;
	int pagesViewed;
	String conversion; 
	
	public ServerItem(Date entryDate, Double id, Date exitDate, int pagesViewed, String conversion){
		super(entryDate, id);
		this.exitDate = exitDate;
		this.pagesViewed = pagesViewed;
		this.conversion = conversion;
	}
	
	public Date getExitDate(){
		return exitDate;
	}
	
	public int getPagesViewed(){
		return pagesViewed;
	}
	
	public boolean isConverted(){
		return conversion.equals("Yes");
	}

	public String getConversion() {
		return conversion;
	}
}
