import java.awt.Button;
import java.awt.Component;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.filechooser.FileNameExtensionFilter;

class MyFileChooser extends JFileChooser{
	Controller controller;
	EvaluationTool evaluationTool;
	
    public MyFileChooser(Controller controller, EvaluationTool evaluationTool, File file) {
    	this.controller = controller;
    	this.evaluationTool = evaluationTool;
    	setCurrentDirectory(file);
    	chooseFiles();
   }
    
    private void chooseFiles(){
    	
		FileNameExtensionFilter csvFilter = new FileNameExtensionFilter("CSV (*.csv)", "csv");
		this.addChoosableFileFilter(csvFilter);
		this.removeChoosableFileFilter(this.getAcceptAllFileFilter());
		this.setMultiSelectionEnabled(true);
		this.setApproveButtonText("Select");
		while (true) {
			int returnVal = this.showOpenDialog(null);
			File[] csvs = this.getSelectedFiles();
			if (csvs.length == 3) {
				try {
					controller.openCSV(csvs[0], csvs[1], csvs[2]);
					evaluationTool.updateKeyMetrics();
					evaluationTool.updateGraphs();
				} catch (IOException ioe) {
					System.err.println(ioe.getMessage());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				evaluationTool.enableButtons();
				break;
			} else if (returnVal == 1) { // if no items were selected
				break;
			} else {
				JOptionPane.showMessageDialog(this, "Please select 3 files");
			}
		}
    }
}
